Steps to run the application
1-First go into Proj 
2-run the django server

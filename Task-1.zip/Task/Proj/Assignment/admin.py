from django.contrib import admin

# Register your models here.
from Assignment.models import StudentForm
# Register your models here.
admin.site.register(StudentForm)